package com.quizapplication;

public class Main {

    public static void main(String[] args) {
	// Quiz Application
        Game game =new Game();
        game.initGame();
        game.play();
    }
}
