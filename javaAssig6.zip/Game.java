package com.quizapplication;

public class Game {
    Question[] questions = new Question[5];
    player player = new player();


    public void initGame(){
      //Created five objects
        for(int i=0;i<3;i++){
          questions[i]=new Question();
      }
        questions[0].question = "who is the Prime minister of India?";
        questions[0].option1="Narendra Modi";
        questions[0].option2="Dr ManMohan Singh";
        questions[0].option3="Akhilesh Yadav";
        questions[0].option4="lalu Yadav";
        questions[0].correctAnswer=1;

        questions[1].question = "Who is the Ceo of Google";
        questions[1].option1="Sundar Pichai";
        questions[1].option2="Ritesh Agrawal";
        questions[1].option3="Bill Gates";
        questions[1].option4="Mark Zukerberg";
        questions[1].correctAnswer=1;


        questions[2].question = "What is the capital of Australia?";
        questions[2].option1="Sydney";
        questions[2].option2="Melbourne";
        questions[2].option3="Perth";
        questions[2].option4="Canberra";
        questions[2].correctAnswer=4;



    }

    public void play(){

        player.getDetails();
        for(int i=0;i<3;i++)
        {
            boolean status = questions[i].askQuestion();
            if(status)
            {
                System.out.println("Amazing! Bahut unda khele he app");
                player.score++;
            }
            else
            {
                System.out.println("maaf karna hum sahayta nhi kr sakte");
            }
            System.out.println(player.name+" Your score is "+ player.score);

        }
    }
}
